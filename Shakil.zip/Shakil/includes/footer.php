<footer>
       <div class="container">
           <div class="col-sm-3">
               <div class="footer-details">
                   <h2>Central Office:</h2>
                   <ul>
                       <li>Ascent Group House 3/D, Road 2/A, Block J,Baridhara, </li>
                       <li><span>Tele: 8860147,8860132,8819500,</span><span>8815222,8856019-20 &amp; 9887277</span></li>
                       <li><span>Fax: (+88 02) 8813141</span> <span> Email: info@scholasticabd.com</span></li>
                       <li>
                           <b><a href=""><i class="fa fa-facebook"></i></a></b>
                           <b><a href=""><i class="fa fa-twitter"></i></a></b>
                           <b><a href=""><i class="fa fa-google-plus"></i></a></b>
                       </li>
                   </ul>
               </div>
           </div><!--col-sm-3 end-->
           
           <div class="col-sm-3">
               <div class="footer-details">
                   <h2>Campus Address:</h2>
                   <ul>
                       <li>
                           <span>Senior campus,Uttara, Plot 2,</span>
                           <span>Road 8 &amp; 9, Sector 1,</span>
                           <span>Uttara Model Town,</span>
                           <span>Dhaka 1230</span>
                        </li>
                       <li><span>Junior campus,Uttara, Plot 1, Road </span><span>21, Sector 4, Uttara Model Town,</span> Dhaka 1230</li>
                       <li><span>Senior Campus,Mirpur, Plot 2/B-2,</span> <span> 2/C line one, Section 13, Mirpur,</span> Dhaka 1216</li>
                   </ul>
               </div>
           </div><!--col-sm-3 end-->
           
           
           <div class="col-sm-3">
               <div class="footer-details">
                   <h2>Campus Address:</h2>
                   <ul>
                       <li>
                           <span>Junior campus,Dhanmondi, Plot 78,</span>
                           <span>Road 8/A, Mirza Golam Hafiz Road,</span>
                           <span> Dhanmondi R/A, Dhaka 1209</span>
                      </li>
                      
                       <li>
                           <span>Junior campus,Gulshan, Plot </span>
                           <span>lot NE(D)3,Gulshan Avenue,North,Shaheed</span>
                           <span> Major , Najmul Haque Sarak,Gulshan 2,</span>
                           <span>Dhaka 1212</span>
                      </li>
                   </ul>
               </div>
           </div><!--col-sm-3 end-->
           
           
           <div class="col-sm-3">
               <div class="footer-details">
                   <h2>Associate School of:</h2>
                   <ul>
                       <li><a href=""><img class="img-responsive" src="img/accociate.png" alt=""></a></li>
                   </ul>
                   
                   <h2>Member of:</h2>
                   <ul>
                       <li>Dhaka International Schools Association (DISA)
                       Bangladesh Private English Medium Schools Forum </li>
                   </ul>
               </div>
           </div><!--col-sm-3 end-->
       </div>  
       <div class="back_to_top"><img src="img/target.png" alt="target"></div>
</footer>
       
  <!--Social Nav-->
  <ul class="social-nav model-0">
  <li><a href="#" class="twitter"><i class="fa fa-facebook"></i></a></li>
  <li><a href="#" class="facebook"><i class="fa fa-twitter"></i></a></li>
  <li><a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a></li>
</ul>   
  
<!--Social Nav-->
   <!-- Add your site or application content here -->
         <script src="js/vendor/jquery-1.12.0.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.enllax.min.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
    </body>
</html>