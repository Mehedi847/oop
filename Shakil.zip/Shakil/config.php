<?php
	$con=mysqli_connect("localhost","root","","varsity");
	if(!$con){
		echo "connection error";
		}
?>